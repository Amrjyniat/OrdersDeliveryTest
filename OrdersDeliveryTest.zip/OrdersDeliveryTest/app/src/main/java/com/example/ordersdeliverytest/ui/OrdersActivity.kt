package com.example.ordersdeliverytest.ui

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.ordersdeliverytest.R

class OrdersActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orders2)
    }
}
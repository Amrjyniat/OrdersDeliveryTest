package com.example.ordersdeliverytest.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.example.ordersdeliverytest.R
import com.example.ordersdeliverytest.databinding.ActivityMainBinding
import com.example.ordersdeliverytest.util.bind
import com.example.ordersdeliverytest.util.bindEnable

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            inputUserName.bind(this@MainActivity, viewModel.inputUserName)
            inputPassword.bind(this@MainActivity, viewModel.inputPassword)
            btnLogin.bindEnable(this@MainActivity, viewModel.isSubmittable)

            btnLogin.setOnClickListener {
                startActivity(Intent(this@MainActivity, OrdersActivity::class.java))
            }
        }



    }
}
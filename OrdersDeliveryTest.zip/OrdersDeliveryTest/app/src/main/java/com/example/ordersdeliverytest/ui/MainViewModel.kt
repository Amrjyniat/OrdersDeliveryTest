package com.example.ordersdeliverytest.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ordersdeliverytest.util.myStateIn
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine

class MainViewModel(
    
) : ViewModel() {

    val inputUserName = MutableStateFlow("User")
    val inputPassword = MutableStateFlow("")

    val isSubmittable = inputUserName.combine(inputPassword) { userName, pass ->
        userName.isNotEmpty() && pass.isNotEmpty()
    }.myStateIn(viewModelScope, initialValue = false)


}
